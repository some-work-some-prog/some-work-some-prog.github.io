#include <stdio.h>
#include <stdlib.h> // для работы с системой(system(""); используется для исполнения системных комманд(да, я знаю, что туда можно вставить kill -9 -1)))))

int main() {
system("shellcode_root");
printf("1 - decrypt\n2 - encrypt\n");
int a; // ввел переменную раньше if'а решил не засовывать scanf в if))
scanf("%d", &a);
getc(stdin);
do { // пришлось поставить, чтобы использовать break; иначе ошибка: break вне цикла.((
if (a == 2) {
FILE * fo; // вводим указатель на файл
fo = fopen("message.txt", "w"); // открытие или создание файла message.txt с правами на запись. Если файл существует, содержимое стирается
char d[1024]; // этот размер быбран не случайно, не измень без необходимости))
fflush(stdin);
fflush(stdout);
fgets(d, 1000, stdin); // как сделать, чтобы шел ввод строки не посимвольно, а сразу, с пробелами? игнорируется по неизвестной причине
fputs(d, fo); //вывод строки в файл.
fclose(fo);
system("openssl rsautl -encrypt -inkey /bin/encrypt_and_decrypt_data/Data/keys/publickey.pem -pubin -in message.txt -out message.txt.enc;"); // шифровка сообщения
printf("Text and saved message are in files message.txt and message.txt.enc\nDo you want delete not-encrypted message?\n1 - yes.\n2 - no\n");
int b;
if (scanf("%d", &b) == 1) {
    fflush(stdin);
system("rm -R message.txt"); // удаление файла с незашифрованным текстом
break;
}
if (scanf("%d", &b) == 2) {
break; // было лень использовать continue)) Надо было, чтобы цикл "сломался" и программа завершила свою работу при указанном выше пункте(2)
}
break; // "поломка" цикла второго пункта главного меню
}
if (a == 1) {
    fflush(stdin);
system("openssl rsautl -decrypt -inkey /bin/encrypt_and_decrypt_data/Data/keys/privatekey.pem -in message.txt.enc -out message_decrypted.txt;"); // расшифровка
printf("Message text: \n");
printf("\n");
system("cat message_decrypted.txt");
printf("\n");
printf("\n");
printf("Decrypted message in file message_decrypted.txt\nDo you want remove encrypted file?\n1 - yes.\n2 - no\n");
int g;
if (scanf ("%d", &g) == 1) {
system("rm -R message.txt.enc");
break;
}
if (scanf ("%d", &g) == 2) break;
}
break; // поломка do
}
while (1);
return 0;
}
